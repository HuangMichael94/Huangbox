import turtle
import random

turtle.hideturtle()
turtle.speed(0)
turtle.colormode(255)

r = 0
g = 0
b = 0
x = 20

while 1 == 1:

    r = random.randint(0,255)
    g = 255 - r
    b = 255 - g
    turtle.pencolor(r, g, b)

    for i in range (30):
    
        turtle.circle(x)
        turtle.right(12)

    x = int(x)  + random.randint(0, 20)
