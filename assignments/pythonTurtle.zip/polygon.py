import turtle

def AnyRegPoly():

    print("enter number of polgon sides")
    sides = int(input())

    print("enter polgon size")
    size = int(input())

    for i in range (0, sides, 1):
        turtle.forward(size)
        turtle.left(360 / sides)

AnyRegPoly()


#circles don't actually exist as they are polygons with infinite sides.
#you can still make practical circles by putting sides to a high number since
#human eyes can't see like 500 sides and it looks like a circle
