
import turtle
turtle.colormode(255)

print("enter background color via RGB")
print("enter amount of red")
r2 = int(input())
print("enter amount of green")
g2 = int(input())
print("enter amount of blue")
b2 = int(input())
turtle.bgcolor(r2, g2, b2)

print("enter turtle speed")
turtle.speed == int(input())

print("enter square size")
size=int(input())

print("make shape [uniform color] or [choose side colors]?")
ans = input()

if ans == "uniform color":
    print("enter shape color via RGB")
    print("enter amount of red")
    r1 = int(input())
    print("enter amount of green")
    g1 = int(input())
    print("enter amount of blue")
    b1 = int(input())
    turtle.color(r1, g1, b1)

    for i in range (4):
        turtle.forward(size)
        turtle.left(90)
    

elif ans == "choose side colors":
    for i in range(4):
            print("enter side color via RGB")
            print("enter amount of red")
            r2 = int(input())
            print("enter amount of green")
            g2 = int(input())
            print("enter amount of blue")
            b2 = int(input())
            turtle.color(r2, g2, b2)
            turtle.forward(size)
            turtle.left(90)
