import turtle

print("what kind of shape to make? choose from:")
print("triangle, square, pentagon, hexagon, nonagon, decagon")
shape = input()

if shape == "triangle":
    print("how large will the shape be?")
    size = int(input())
    for i in range(3):
        turtle.forward(size)
        turtle.left(120)

elif shape == "square":
    print("how large will the shape be?")
    size = int(input())
    for i in range(4):
        turtle.forward(size)
        turtle.left(90)

elif shape == "pentagon":
    print("how large will the shape be?")
    size = int(input())
    for i in range(5):
        turtle.forward(size)
        turtle.left(72)

elif shape == "hexagon":
    print("how large will the shape be?")
    size = int(input())
    for i in range(6):
        turtle.forward(size)
        turtle.left(60)

elif shape == "nonagon":
    print("how large will the shape be?")
    size = int(input())
    for i in range(9):
        turtle.forward(size)
        turtle.left(40)


elif shape == "decagon":
    print("how large will the shape be?")
    size = int(input())
    for i in range(10):
        turtle.forward(size)
        turtle.left(36)




























