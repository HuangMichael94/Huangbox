import turtle
turtle.speed == 0

def main1():
    print("share [corner] or [center]?")
    ans = input()

    print("enter number of sides")
    sides = int(input())

    print("enter number of shapes")
    num = int(input())

    print("enter size")
    size = int(input())

    print("enter size increments")
    change = int(input())

    if ans == "corner":
        ang = 360 / sides
        for i in range (num):
            for n in range (sides):   
                turtle.forward(size)
                turtle.right(ang)
            size = size + change

    elif ans == "center":
        ang = 360 / sides
        x=1
        for i in range (num):
            for n in range (sides):   
                turtle.forward(size)
                turtle.right(ang)
            turtle.goto (0-((x * change)/2), 0+((x * change)/2))
            x=x+1
            size = size + change
#main1()

    
print("enter number of regular polygon series")
num = int(input())

print("enter size")
size = int(input())

sides = 3

for i in range (num):
    for  n in range (sides):
        turtle.forward(size)
        turtle.right(360/sides)
    sides = int(sides) + 1



































