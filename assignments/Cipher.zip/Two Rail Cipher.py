
#print("enter sentence")
#sample = input()
#
#even = ""
#odd = ""
#acc = 0
#
#for ch in (sample):
#    if acc % 2 == 0:
#        even = even + ch
#
#    elif acc % 2 == 1:
#        odd = odd + ch
#
#    acc = acc + 1
#
#end = even + odd
#print(end)


########################################################################


string = "!ogauain! Yuhv eihrdm oe )~Cnrtltos~ o aeDcpee ycd!;"
newstring = ""
end = ""
acc = 0
acc2 = 0
acc3 = 0
part1 = ""
part2 = ""

for ch in string:

    if acc < len(string)/2:
        part1 = part1 + ch
        acc = acc + 1
    
    else:
        part2 = part2 + ch

newstring = part2 + part1


print(string)
print("")

print(newstring)
print("")

for i in range (int(len(string)/2)):

    end = end + part2[0 + acc3]

    end = end + part1[0 + acc3]

    acc3 = acc3 + 1

print(end)








































