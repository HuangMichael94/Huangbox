blank = ""

print("enter encrypted password")
string = input()

for ch in string:
    if ch == "!":
        blank = blank + "a"
    elif ch == "@":
        blank = blank + "e"
    elif ch == "#":
        blank = blank + "i"
    elif ch == "$":
        blank = blank + "o"
    elif ch == "%":
        blank = blank + "u"
    else:
        blank = blank + ch
print("")
print("decrypted:")
print(blank)
