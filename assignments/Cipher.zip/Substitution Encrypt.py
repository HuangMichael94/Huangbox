
blank = ""

print("enter password")
string = input()

for ch in string:
    if ch == "a":
        blank = blank + "!"
    elif ch == "e":
        blank = blank + "@"
    elif ch == "i":
        blank = blank + "#"
    elif ch == "o":
        blank = blank + "$"
    elif ch == "u":
        blank = blank + "%"
    else:
        blank = blank + ch
print("")
print("encrypted:")
print(blank)
